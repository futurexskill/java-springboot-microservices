package com.futurex.microservices.FXPaymentService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FxPaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
