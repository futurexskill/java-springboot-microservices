package com.futurex.microservices.FXPaymentService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FxPaymentServiceApplication {

	public static void main(String[] args) {

		SpringApplication.run(FxPaymentServiceApplication.class, args);
	}

}
